# Powered by Maelstrom: brand assets

Assets for crediting **Maelstrom** (https://maelstrom-ai.co) in products, demos and videos.

## Colors
| Use | Hex |
|---|---|
| Maelstrom Blue (mark, accents) | `#0091FF` |
| Dark background (end cards) | `#050810` |
| Dark UI / pill / dark text | `#0B1220` |
| White text on dark | `#FFFFFF` / `#F1F4F8` |
| Muted text ("Powered by") | `#A3ADBD` (dark UI), `#5B6474` (light UI) |

Type: Inter (wordmark SemiBold, badge text Regular + SemiBold). Every SVG has its text converted to outlines, so you don't need to install any fonts.

## Files
| File | Use it for |
|---|---|
| `logo-mark.svg` / `.png` (1024²) / `-512px.png` | The mark on its own (transparent). App icons, avatars, small spaces. |
| `logo-lockup-dark.svg` / `.png` (2400 px wide) / `-1200px.png` | Mark + "maelstrom" wordmark with white text, for **dark** backgrounds. |
| `logo-lockup-light.svg` / `.png` / `-1200px.png` | Same lockup with near-black text, for **light** backgrounds. |
| `powered-by-badge-dark.svg` / `.png` / `-8x.png` | "Powered by Maelstrom" pill for dark UIs (navy pill, blue mark). |
| `powered-by-badge-light.svg` / … | White pill version for light UIs. |
| `powered-by-badge-mono-white.svg` / … | All-white, no pill. Overlays on video or dark photos. |
| `powered-by-badge-mono-black.svg` / … | All-black, no pill. Overlays on light photos or print. |
| `video-endcard-16x9.png` (1920×1080) + `.svg` | Intro/outro card for landscape video. |
| `video-endcard-9x16.png` (1080×1920) + `.svg` | Intro/outro card for vertical/social video. |

Use the SVGs wherever you can, because they scale with no quality loss. The badge PNGs are rendered at 4× (`.png`) and 8× (`-8x.png`) of the 269×56 base size.

## Rules
- **Clear space:** keep empty space around the logo of at least ⅓ of the mark's height (about one lobe of the mark) on every side.
- **Minimum size:** mark 16 px; lockup 80 px wide; badge 28 px tall.
- Don't recolor the mark outside blue, white or black. Don't stretch, rotate, outline or add effects to it, and don't put the blue mark on busy or mid-blue backgrounds (use the mono badge there).
- The wordmark is always lowercase: **maelstrom**. In running text and in the badge, write **Maelstrom**.

## Suggested attribution
> Powered by Maelstrom: https://maelstrom-ai.co

## License note
Maelstrom is MIT-licensed open source. The MIT license covers the code. The Maelstrom name and logo here are provided **for attribution only**, to credit Maelstrom in projects built with it. They don't grant trademark rights or imply endorsement.
